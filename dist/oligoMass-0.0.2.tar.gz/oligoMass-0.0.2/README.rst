Description
===========

Oligonucleotides properties calculation packege.

Installation
============

from Repository on GitHub:

pip install git+https://github.com/a1exsan/oligoMass.git#egg=oligoMass