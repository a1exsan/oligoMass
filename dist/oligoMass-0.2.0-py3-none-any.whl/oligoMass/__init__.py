__version__ = '0.1.9'


__all__ = [
    'dna',
    'molmassOligo',
    'exModifications',
    'ElementsTable'
]