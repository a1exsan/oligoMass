__version__ = '0.0.3'


__all__ = [
    'dna',
    'molmassOligo',
    'exModifications'
]